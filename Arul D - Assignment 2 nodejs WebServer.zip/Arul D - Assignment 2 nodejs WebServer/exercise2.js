const express = require("express");
const fs = require("fs");
const { parse } = require("csv-parse");
const app = express();

app.get("/", (req, res) => {
  const stream = fs.createReadStream("./lib/user.txt");
  const parser = parse({ delimiter: "|" });
  const rows = [];
  parser.on("readable", () => {
    let record;
    while ((record = parser.read())) {
      rows.push(record);
    }
  });

  parser.on("end", () => {
    const header = rows.shift();
    let table = "<table>";
    table += "<tr>";
    for (let cell of header) {
      table += `<th>${cell}</th>`;
    }
    table += "</tr>";
    for (let row of rows) {
      table += "<tr>";
      for (let cell of row) {
        table += `<td>${cell}</td>`;
      }
      table += "</tr>";
    }
    table += "</table>";
    res.set("Content-Type", "text/html");
    res.send(table);
  });
  stream.pipe(parser);
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});
