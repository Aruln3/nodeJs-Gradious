const express = require("express");
const path = require("path");
const app = express();

app.get("/", (req, res) => {
  const homePath = path.resolve(__dirname, "./lib/index.html");
  res.sendFile(homePath);
});

app.get("/home", (req, res) => {
  const homePath = path.resolve(__dirname, "./lib/home.html");
  res.sendFile(homePath);
});

app.get("/contact", (req, res) => {
  const contactPath = path.resolve(__dirname, "./lib/contact.html");
  res.sendFile(contactPath);
});

app.get("/about", (req, res) => {
  const aboutPath = path.resolve(__dirname, "./lib/about.html");
  res.sendFile(aboutPath);
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});
