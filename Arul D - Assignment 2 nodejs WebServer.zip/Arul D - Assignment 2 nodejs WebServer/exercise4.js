app.get('/',(req,res) => {
  const contactPath = path.resolve(__dirname, "./home.html");
  res.sendFile(contactPath);
});

const express = require('express');
const app = express();

app.use(express.static('lib'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
 console.log(`Server is running on port ${PORT}`);
})