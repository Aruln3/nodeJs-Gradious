const express = require("express");
const fs = require("fs");
const app = express();

function getEmployeesO(employees) {
  for (let employee of employees) {
    if (employee.salary > 50000) {
      employee.tier = 1;
    } else {
      employee.tier = 2;
    }
  }
  return employees;
}

app.get("/", (req, res) => {
  fs.readFile("./lib/employees.txt", "utf8", (err, data) => {
    if (err) {
      res.status(500).send("Something went wrong");
    } else {
      let employees = JSON.parse(data);
      let result = getEmployeesO(employees);
      res.json(result);
      console.log(result);
    }
  });
});

app.listen(3000, () => {
  console.log("Server is running on port 3000");
});

