const fs = require("fs");
fs.readFile("./lib/employees.txt", "utf8", (err, data) => {
 if (err) {
   console.error("Error reading the file:", err);
   return;
 }
 try {
   const employees = JSON.parse(data);
   const city = "Hyderabad";
   const hyderabadEmployees = employees.filter(employee => employee.city === city);
   const totalSalaryHyderabad = hyderabadEmployees.reduce((acc, employee) => acc + employee.salary, 0);
   console.log("Total Salary of Hyderabad Employees:", totalSalaryHyderabad);
 } catch (error) {
   console.error("Error parsing JSON data:", error);
 }
});