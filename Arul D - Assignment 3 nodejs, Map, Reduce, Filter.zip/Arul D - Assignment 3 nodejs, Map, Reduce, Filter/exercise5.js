const fs = require("fs");
fs.readFile("./lib/employees.txt", "utf8", (err, data) => {
  if (err) {
    console.error("Error reading the file:", err);
    return;
  }
  try {
    const employees = JSON.parse(data);
    for (let employee of employees) {
      if (employee.salary > 50000) {
        employee.tier = 1;
      } else {
        employee.tier = 2;
      }
    }
    const tier1Employees = employees.filter(employee => employee.tier === 1);
    const totalSalaryTier1 = tier1Employees.reduce((acc, employee) => acc + employee.salary, 0);
    console.log("Total Salary of Tier 1 Employees:", totalSalaryTier1);
  } catch (error) {
    console.error("Error parsing JSON data:", error);
  }
});
