const fs = require('fs');
function getFileContent(checkfile){
fs.readFile(checkfile, 'utf8', function(err, data) {
  if (err) {
    console.error(err);
  }
  console.log(data);
});
}

var readme = './lib/readme.txt';
var students = './lib/students.csv';
var indexFile = './lib/index.html';

getFileContent(readme);
getFileContent(students);
getFileContent(indexFile);