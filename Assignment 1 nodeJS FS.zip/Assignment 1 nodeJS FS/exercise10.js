var XLSX = require('xlsx')
var sheet = XLSX.readFile('./lib/exercise10.xlsx');
var list = sheet.SheetNames;
var xlData = XLSX.utils.sheet_to_json(sheet.Sheets[list[0]]);
console.log(xlData);