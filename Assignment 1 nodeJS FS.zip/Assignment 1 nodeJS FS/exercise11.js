var XLSX = require('xlsx');
var jsonData = [{"name" : "Ananor", "age":22, "gender":0, "city" : "Mumbai"}, {"name": "Bihu", "age":17, "gender":1, "city" :"Pune"}];
var sheet = XLSX.utils.book_new();
var list = XLSX.utils.json_to_sheet(jsonData); 
XLSX.utils.book_append_sheet(sheet, list, 'Sheet');
XLSX.writeFile(sheet, './lib/exercise11.xlsx'); 
