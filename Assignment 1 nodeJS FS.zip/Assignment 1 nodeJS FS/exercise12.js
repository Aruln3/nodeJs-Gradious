var path = process.env.PATH;
console.log('\n' + path +'\n');
