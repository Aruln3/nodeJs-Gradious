const fs = require('fs');
function generateRandomString(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
  result += chars[Math.floor(Math.random() * chars.length)];
}
  return result;
}

  function writeRandom(filename, num, length){
  let words = [];
  for (let i = 0; i < num; i++) {
    words.push(generateRandomString(length));
 }
  fs.writeFile(filename, words.join('\n'), (err) => {
    if (err) {
      console.error(err);
    } else {
      console.log('successfully created');
      console.log(words);
    }
  });
}
writeRandom('./lib/exercise2.txt', 100, 10);