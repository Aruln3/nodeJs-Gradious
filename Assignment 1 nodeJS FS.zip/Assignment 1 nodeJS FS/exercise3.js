const fs = require('fs');
fs.copyFile('./lib/exercise2.txt', './lib/exercise3.txt', (err) => {
  if (err) throw err;
  console.log('exercise2 was copied to exercise3');
});
