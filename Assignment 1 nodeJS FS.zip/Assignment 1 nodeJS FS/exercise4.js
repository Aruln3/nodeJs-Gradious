const fs = require('fs');
fs.rename('./lib/exercise4.txt', './lib/newexercise4.txt', (err) => {
  if (err) throw err;
  console.log('exercise4 was renamed to newexercise4');
});
