const fs = require('fs');
const file = './lib/exercise5.txt';
const word = 'readme';
fs.readFile(file, 'utf8', (err, data) => {
  if (err) throw err;
  const lines = data.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const index = lines[i].indexOf(word);
    if (index !== -1) {
      console.log(`readme present @ Line at ${i + 1} in exercise5 text file`);
    }  
  }
});