const fs = require('fs');
const os = require('os');
const data = fs.readFileSync('./lib/exercise6.txt', 'utf8');
const lines = data.split(os.EOL); //used to get end-of-line character
const newLines = lines.map((line, index) => index < lines.length - 1 ? line + os.EOL + os.EOL : line).join('');
console.log(newLines);
fs.writeFileSync('./lib/exercise6.txt', newLines, 'utf8');
