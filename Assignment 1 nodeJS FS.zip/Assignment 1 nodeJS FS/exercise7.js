const fs = require('fs');
const os = require('os');
const data = fs.readFileSync('./lib/exercise7.txt', 'utf8');
const lines = data.split(os.EOL);

const date = new Date();
const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];
const year = date.getFullYear();
const month = monthNames[date.getMonth()];
const day = date.getDate();
const hour = date.getHours();
const minute = date.getMinutes();
const second = date.getSeconds();
const amandpm = hour >= 12 ? 'PM' : 'AM';
const timestamp = `${day}-${month}-${year}${hour}:${minute}:${second} ${amandpm}`;

const newLines = lines.map(line => timestamp + ' ' + line).join(os.EOL);
fs.writeFileSync('./lib/exercise7.txt', newLines, 'utf8');
