const fs = require('fs');
const data = fs.readFileSync('./lib/exercise8.txt', 'utf8');
const lines = data.split('\n');
const jsonArray = [];
for (let line of lines) {
  const fields = line.split('|');
  const obj = {
    name: fields[0],
    age: fields[1],
    gender: fields[2],
    city: fields[3]
  };
  jsonArray.push(obj);
}

const jsonString = JSON.stringify(jsonArray);
console.log(jsonString);
