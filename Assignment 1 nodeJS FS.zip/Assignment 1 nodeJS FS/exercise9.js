const fs = require('fs');
const jsonString = '[{"name":"Ananor","age":22,"gender":0,"city":"Mumbai"},{"name":"Bihu","age":17,"gender":1,"city":"Pune"}]';
const jsonArray = JSON.parse(jsonString);
let data = '';
for (let person of jsonArray) {
  let line = `Name: ${person.name}, Age: ${person.age}, Gender: ${person.gender}, City: ${person.city}\n`;
  data += line;
}
fs.writeFileSync('./lib/exercise9.txt', data, 'utf8');