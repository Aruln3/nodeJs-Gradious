
Hi

exercise 1 readme readed!
