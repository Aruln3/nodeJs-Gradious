const fs = require('fs');

fs.readFile('./sample.txt', 'utf8', function(err, data) {
  if (err) {
    console.error(err);
  }
  console.log(data);
});
